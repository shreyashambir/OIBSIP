function clicked(siteName){
    var URL ='';
    if(siteName == 'fb'){
        URL = 'https://www.facebook.com/shreyas.hambir'
    }
    if(siteName == 'ig'){
        URL = 'https://www.instagram.com/hambir_shreyas_1680/'
    }
    if(siteName == 'gh'){
        URL = 'https://github.com/shreyashambir/OIBSIP'
    }
    if(siteName == 'tw'){
        URL = 'https://twitter.com/Hambir21?t=WOpuWisNDw9sa0jdqSb03A&s=09'
    }
    window.open(URL, '_blank');
}